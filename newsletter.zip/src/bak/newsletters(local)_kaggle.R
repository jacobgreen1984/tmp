library(rvest)
library(dplyr)
library(stringr)
library(data.table)
library(R2HTML)
library(NLP)
library(openNLP)
options(timeout= 4000000)


###### Local ############################################################
path <- "C:/Users/user/Documents/DS_lab/2econsulting.github.io/data/newsletter/"

from <- substr(as.character(format(Sys.time()-(14*24*60*60), "%Y-%m-%d %H:%M:%00")),1, 10)
to   <- substr(as.character(format(Sys.time(), "%Y-%m-%d %H:%M:%00")), 1, 10)

# analyticsvidhya ----
# Get the url 
for (j in 1:5) {
  i <- "http://blog.kaggle.com/"
  tmp_base <- read_html(i)
  print("Done")
}
Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.entry-date')
tmp_time <- html_text(tmp_time)
Sys.sleep(3)
tmp_time <- as.Date(tmp_time, format = '%m. %d. %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, '.entry-title')
tmp_head <- html_text(tmp_head)
tmp_head <- gsub("\n      ","",tmp_head)
tmp_head <- gsub("\n    ","",tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, '.entry-featured a')
tmp_url <- html_attr(tmp_url, 'href')

# make data frame
kaggle <- data.frame(site = "kaggle", date = tmp_time, headline = tmp_head, url_address = tmp_url)
kaggle <- as.data.table(unique(kaggle))

# Get the valid information 
kaggle <- kaggle[from < kaggle$date & to >= kaggle$date, ]

# Collect the data from valid url
tmp_text <- c()
for (i in kaggle[["url_address"]]){
  for (j in 1:5) {
    tmp <- read_html(i)
    print("Done")
  }
  Sys.sleep(3)
  tmp <- html_nodes(tmp, 'p') 
  tmp <- html_text(tmp) 
  Sys.sleep(3)
  tmp <- tmp[2:(length(tmp)-9)] # remove advertisement
  tmp <- tmp[str_length(tmp)>1] # remove empty line
  tmp <- paste(unlist(tmp), collapse =" ")
  Sys.sleep(2)
  tmp_text <- c(tmp_text, tmp)
}
kaggle$text <- tmp_text
filename <- paste0(path,"input/kaggle_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
write.csv(kaggle, filename, row.names = FALSE)

html <- paste0('<ul><li><a href="',kaggle$url_address,'">',kaggle$headline,'</a></li></ul>')
write.table(html, paste0(path,"input/html/kaggle_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, filename, html)


rm(list = ls())