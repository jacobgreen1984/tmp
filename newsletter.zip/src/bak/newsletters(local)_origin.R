library(rvest)
library(dplyr)
library(stringr)
library(data.table)
library(R2HTML)
library(NLP)
library(openNLP)
options(timeout= 4000000)


###### Local ############################################################
path <- "C:/Users/user/Documents/DS_lab/2econsulting.github.io/data/newsletter/"

from <- substr(as.character(format(Sys.time()-(7*24*60*60), "%Y-%m-%d %H:%M:%00")),1, 10)
to   <- substr(as.character(format(Sys.time(), "%Y-%m-%d %H:%M:%00")), 1, 10)

# analyticsvidhya ----
# Get the url 
url <- "https://www.analyticsvidhya.com/blog-archive/"

get_baseHTML <- function(url){
  for (i in url){
    baseHTML <- try(read_html(i), silent = TRUE)
    if(inherits(baseHTML, "tye-error"))
    {
      baseHTML <- read_html(i)
      next
    }
    print("Done")
  }
  baseHTML <- read_html(url)
  return(baseHTML)
}

baseHTML <- get_baseHTML(url)

for (i in url){
  tmp_base <- try(read_html(i), silent = TRUE)
  if(inherits(tmp_base, "tye-error"))
  {
    tmp_base <- read_html(i)
    next
  }
  print("Done")
}
i <- "https://www.analyticsvidhya.com/blog-archive/"
tmp_base <- read_html(i)
Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.entry-date')
tmp_time <- html_text(tmp_time)

tmp_time <- gsub("\n","",tmp_time)
tmp_time <- gsub("\n ","",tmp_time)
tmp_time <- gsub(paste0(substr(from, 1, 4), " "),"2018",tmp_time)
tmp_time <- gsub(paste0(substr(to, 1, 4), " "),"2018",tmp_time)
tmp_time <- gsub(",","",tmp_time)
tmp_time <- gsub(" J","J",tmp_time)

# 일자 변수 변환: format에서 %B가 안되기 때문에 숫자로 변환 후 %m 이용 
tmp_time <- gsub("January", 1, tmp_time)
tmp_time <- gsub("February", 2, tmp_time)
tmp_time <- gsub("March", 3, tmp_time)
tmp_time <- gsub("April", 4, tmp_time)
tmp_time <- gsub("May", 5, tmp_time)
tmp_time <- gsub("June", 6, tmp_time)
tmp_time <- gsub("July", 7, tmp_time)
tmp_time <- gsub("August", 8, tmp_time)
tmp_time <- gsub("September", 9, tmp_time)
tmp_time <- gsub("October", 10, tmp_time)
tmp_time <- gsub("November", 11, tmp_time)
tmp_time <- gsub("December", 12, tmp_time)
tmp_time <- as.Date(tmp_time, format = '%m %d %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, '.entry-title')
tmp_head <- html_text(tmp_head)

tmp_head <- tmp_head[!(tmp_head %in% tmp_head[[1]])]
tmp_head <- gsub("\n\n","",tmp_head)
tmp_head <- gsub(" \n","",tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, '.entry-title a')
tmp_url <- html_attr(tmp_url, 'href')

# make data frame
vidhya <- data.frame(site = "vidhya", date = tmp_time, headline = tmp_head, url_address = tmp_url)
vidhya <- as.data.table(unique(vidhya))

# Get the valid information 
vidhya <- vidhya[from < vidhya$date & to >= vidhya$date, ]

# Collect the data from valid url
for (j in 1){
  if (nrow(vidhya) == 0){
    vidhya <- data.frame(matrix(vector(), 0, 5,
                                dimnames = list(c(), c("site", "date","headline","url_address","text"))),
                         stringsAsFactors = FALSE)
    vidhya$site <- as.factor(vidhya$site)
    vidhya$date <- as.Date(vidhya$date)
    vidhya$headline <- as.factor(vidhya$headline)
    vidhya$url_address <- as.factor(vidhya$url_address)
    vidhya$text <- as.factor(vidhya$text)
    html <- paste0('<li>','no new article','</li>')
    write.table(html, paste0(path,"input/html/vidhya_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, i, j, html, url)
  }
  else{
    tmp_text <- c()
    for (url in vidhya[["url_address"]]){
      for (i in url){
        tmp <- try(read_html(i), silent = TRUE)
        if(inherits(tmp_base, "tye-error"))
        {
          tmp <- read_html(i)
          next
        }
        print("Done")
      }
      tmp <- read_html(i)
      Sys.sleep(3)
      tmp <- html_nodes(tmp, 'p')
      tmp <- html_text(tmp) 
      Sys.sleep(3)
      tmp <- tmp[1:(length(tmp)-11)] # remove advertisement
      tmp <- tmp[str_length(tmp)>1] # remove empty line
      tmp <- paste(unlist(tmp), collapse =" ")
      tmp_text <- c(tmp_text, tmp)
      Sys.sleep(2)
    }
    vidhya$text <- tmp_text
    filename <- paste0(path,"input/vidhya_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
    write.csv(vidhya, filename, row.names = FALSE)
    
    html <- paste0('<ul><li><a href="',vidhya$url_address,'">',vidhya$headline,'</a></li></ul>')
    write.table(html, paste0(path,"input/html/vidhya_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, j, filename, html)
  }
}
gc()

# kaggle blog ----
# Get the url
url <- "http://blog.kaggle.com/"
for (i in url){
  tmp_base <- try(read_html(i), silent = TRUE)
  if(inherits(tmp_base, "tye-error"))
  {
    tmp_base <- read_html(i)
    next
  }
  print("Done")
}
i <- "http://blog.kaggle.com/"
tmp_base <- read_html(i)

Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.entry-date')
tmp_time <- html_text(tmp_time)
Sys.sleep(3)
tmp_time <- as.Date(tmp_time, format = '%m. %d. %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, '.entry-title')
tmp_head <- html_text(tmp_head)
tmp_head <- gsub("\n      ","",tmp_head)
tmp_head <- gsub("\n    ","",tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, '.entry-featured a')
tmp_url <- html_attr(tmp_url, 'href')

# make data frame
kaggle <- data.frame(site = "kaggle", date = tmp_time, headline = tmp_head, url_address = tmp_url)
kaggle <- as.data.table(unique(kaggle))

# Get the valid information 
kaggle <- kaggle[from < kaggle$date & to >= kaggle$date, ]

# Collect the data from valid url
for (j in 1){
  if (nrow(kaggle) == 0){
    kaggle <- data.frame(matrix(vector(), 0, 5,
                             dimnames = list(c(), c("site", "date","headline","url_address","text"))),
                      stringsAsFactors = FALSE)
    kaggle$site <- as.factor(kaggle$site)
    kaggle$date <- as.Date(kaggle$date)
    kaggle$headline <- as.factor(kaggle$headline)
    kaggle$url_address <- as.factor(kaggle$url_address)
    kaggle$text <- as.factor(kaggle$text)
    html <- paste0('<li>','no new article','</li>')
    write.table(html, paste0(path,"input/html/kaggle_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, i, j, html, url)
  }
  else{
    tmp_text <- c()
    for (url in kaggle[["url_address"]]){
      for (i in url){
        tmp_base <- try(read_html(i), silent = TRUE)
        if(inherits(tmp_base, "tye-error"))
        {
          tmp_base <- read_html(i)
          next
        }
        print("Done")
      }
      tmp <- read_html(url)
      Sys.sleep(3)
      tmp <- html_nodes(tmp, 'p') 
      tmp <- html_text(tmp) 
      Sys.sleep(3)
      tmp <- tmp[2:(length(tmp)-9)] # remove advertisement
      tmp <- tmp[str_length(tmp)>1] # remove empty line
      tmp <- paste(unlist(tmp), collapse =" ")
      Sys.sleep(2)
      tmp_text <- c(tmp_text, tmp)
    }
    kaggle$text <- tmp_text
    filename <- paste0(path,"input/kaggle_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
    write.csv(kaggle, filename, row.names = FALSE)
    
    html <- paste0('<ul><li><a href="',kaggle$url_address,'">',kaggle$headline,'</a></li></ul>')
    write.table(html, paste0(path,"input/html/kaggle_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, j, filename, html)
  }
}
gc()


# datacamp blog ----
# Get the time
url <- "https://www.datacamp.com/community/blog"
for (i in url){
  tmp_base <- try(read_html(i), silent = TRUE)
  if(inherits(tmp_base, "tye-error"))
  {
    tmp_base <- read_html(i)
    next
  }
  print("Done")
}
i <- "https://www.datacamp.com/community/blog"
tmp_base <- read_html(i)

Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.jsx-566588255 a .date')
tmp_time <- html_text(tmp_time)

# 일자 변수 변환: format에서 %B가 안되기 때문에 숫자로 변환 후 %m 이용 
tmp_time <- gsub("st","",tmp_time)
tmp_time <- gsub("nd","",tmp_time)
tmp_time <- gsub("rd","",tmp_time)
tmp_time <- gsub("th","",tmp_time)

tmp_time <- gsub("January", 1, tmp_time)
tmp_time <- gsub("February", 2, tmp_time)
tmp_time <- gsub("March", 3, tmp_time)
tmp_time <- gsub("April", 4, tmp_time)
tmp_time <- gsub("May", 5, tmp_time)
tmp_time <- gsub("June", 6, tmp_time)
tmp_time <- gsub("July", 7, tmp_time)
tmp_time <- gsub("August", 8, tmp_time)
tmp_time <- gsub("September", 9, tmp_time)
tmp_time <- gsub("October", 10, tmp_time)
tmp_time <- gsub("November", 11, tmp_time)
tmp_time <- gsub("December", 12, tmp_time)
tmp_time <- as.Date(tmp_time, format = '%m %d, %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, 'h2')
tmp_head <- html_text(tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, 'h2 a')
tmp_url <- html_attr(tmp_url, 'href')
url_list <- c()
for (i in tmp_url){
  tmp <- paste0("https://www.datacamp.com",i)
  url_list <- c(url_list, tmp)
}

# make data frame
datacamp <- data.frame(site = "datacamp", date = as.Date(tmp_time), headline = as.character(tmp_head), url_address = as.character(url_list))
datacamp <- as.data.table(unique(datacamp))

# Get the valid information 
datacamp <- datacamp[from < datacamp$date & to >= datacamp$date, ]

# Collect the data from valid url
for (j in 1){
  if (nrow(datacamp) == 0){
    datacamp <- data.frame(matrix(vector(), 0, 5,
                                dimnames = list(c(), c("site", "date","headline","url_address","text"))),
                         stringsAsFactors = FALSE)
    datacamp$site <- as.factor(datacamp$site)
    datacamp$date <- as.Date(datacamp$date)
    datacamp$headline <- as.factor(datacamp$headline)
    datacamp$url_address <- as.factor(datacamp$url_address)
    datacamp$text <- as.factor(datacamp$text)
    html <- paste0('<li>','no new article','</li>')
    write.table(html, paste0(path,"input/html/datacamp_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, j, i, html, url)
  }
  else {
    tmp_text <- c()
    for (url in datacamp[["url_address"]]){
      for (i in url){
        tmp_base <- try(read_html(i), silent = TRUE)
        if(inherits(tmp_base, "tye-error"))
        {
          tmp_base <- read_html(i)
          next
        }
        print("Done")
      }
      tmp <- read_html(url)
      Sys.sleep(3)
      tmp <- html_nodes(tmp, 'p') 
      tmp <- html_text(tmp) 
      Sys.sleep(3)
      tmp <- tmp[str_length(tmp)>1] # remove empty line
      tmp <- tmp[2:(length(tmp))] # remove advertisement
      tmp <- paste(unlist(tmp), collapse =" ")
      tmp_text <- c(tmp_text, tmp)
      Sys.sleep(3)
    }
    datacamp$text <- tmp_text
    filename <- paste0(path,"input/datacamp_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
    write.csv(datacamp, filename, row.names = FALSE)
    
    html <- paste0('<ul><li><a href="',datacamp$url_address,'">',datacamp$headline,'</a></li></ul>')
    write.table(html, paste0(path,"input/html/datacamp_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, j, filename, html, url_list)
  }
}
gc()


# machine learning mastery ----
# Get the valid url (time limit : one week) 
#i <- "https://machinelearningmastery.com/blog/"
#tmp_base <- read_html(i)
url <- "https://machinelearningmastery.com/blog/"
for (i in url){
  tmp_base <- try(read_html(i), silent = TRUE)
  if(inherits(tmp_base, "tye-error"))
  {
    tmp_base <- read_html(i)
    next
  }
  print("Done")
}
i <- "https://machinelearningmastery.com/blog/"
tmp_base <- read_html(i)
Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, 'abbr')
tmp_time <- html_attr(tmp_time, "title")
tmp_time <- as.Date(substr(as.character(tmp_time),1,10), "%Y-%m-%d")

# Get the title
tmp_head <- html_nodes(tmp_base, 'h2')
tmp_head <- html_text(tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, 'h2 a')
tmp_url <- html_attr(tmp_url, 'href')

# make data frame
mastery <- data.frame(site = "mastery", date = tmp_time, headline = tmp_head, url_address = tmp_url)
mastery <- as.data.table(unique(mastery))

# Get the valid information 
mastery <- mastery[from < mastery$date & to >= mastery$date, ]

# Collect the data from valid url
for (j in 1){
  if (nrow(mastery) == 0){
    mastery <- data.frame(matrix(vector(), 0, 5,
                                  dimnames = list(c(), c("site", "date","headline","url_address","text"))),
                           stringsAsFactors = FALSE)
    mastery$site <- as.factor(mastery$site)
    mastery$date <- as.Date(mastery$date)
    mastery$headline <- as.factor(mastery$headline)
    mastery$url_address <- as.factor(mastery$url_address)
    mastery$text <- as.factor(mastery$text)
    html <- paste0('<li>','no new article','</li>')
    write.table(html, paste0(path,"input/html/mastery_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, i, j, html, url)
  }
  else{
    tmp_text <- c()
    for (i in mastery[["url_address"]]){
      for (i in url){
        tmp_base <- try(read_html(i), silent = TRUE)
        if(inherits(tmp_base, "tye-error"))
        {
          tmp_base <- read_html(i)
          next
        }
        print("Done")
      }
      tmp <- read_html(url)
      Sys.sleep(3)
      tmp <- html_nodes(tmp, 'p') 
      tmp <- html_text(tmp) 
      Sys.sleep(3)
      tmp <- tmp[2:(length(tmp)-7)] # remove advertisement
      tmp <- tmp[str_length(tmp)>1] # remove empty line
      tmp <- paste(unlist(tmp), collapse =" ")
      tmp_text <- c(tmp_text, tmp)
      Sys.sleep(2)
    }
    mastery$text <- tmp_text
    filename <- paste0(path,"input/mastery_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
    write.csv(mastery, filename, row.names = FALSE)
    
    html <- paste0('<ul><li><a href="',mastery$url_address,'">',mastery$headline,'</a></li></ul>')
    write.table(html, paste0(path,"input/html/mastery_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
    rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, j, filename, html)
  }
}
gc()

total <- rbind(kaggle, datacamp, mastery, vidhya)
filename <- paste0(path,"input/total_",gsub("-", "", Sys.Date()),".csv")
write.csv(total, filename, row.names = FALSE)

rm(list = ls())
