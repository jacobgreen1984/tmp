# library 
library(devtools)
devtools::install_github("johndharrison/binman")
devtools::install_github("johndharrison/wdman")
devtools::install_github("ropensci/RSelenium")
devtools::install_github("lchiffon/wordcloud2")
library(wordcloud)
library(htmlwidgets)
library(RSelenium)
library(stringr)
library(data.table)
library(NLP)
library(openNLP)
gc()
# function
KeywordExtract <- function(tmp_text, ...){
  s <- as.String(tmp_text)
  s <- tolower(s)
  word_token_annotator <- Maxent_Word_Token_Annotator()
  a2 <- Annotation(1L, "sentence", 1L, nchar(s))
  a2 <- annotate(s, word_token_annotator, a2)
  a3 <- annotate(s, Maxent_POS_Tag_Annotator(), a2)
  a3w <- a3[a3$type == "word"]
  POStags <- unlist(lapply(a3w$features, `[[`, "POS"))
  POStagged <- paste(sprintf("%s/%s", s[a3w], POStags), collapse = " ")
  Tag <- list(POStagged = POStagged, POStags = POStags)
  Sys.sleep(3)
  prp1 <- str_extract_all(Tag$POStagged,"\\w+/NNS\\$?")
  prp2 <- str_extract_all(Tag$POStagged,"\\w+/NNP\\$?")
  prp3 <- str_extract_all(Tag$POStagged,"\\w+/NN\\$?")
  prp1 <- str_replace(unlist(prp1), "/NNS\\$?", "")
  prp2 <- str_replace(unlist(prp2), "/NNP\\$?", "")
  prp3 <- str_replace(unlist(prp3), "/NN\\$?", "")
  tmp <- list(prp1, prp2, prp3)
  freq_table  <- as.data.frame.table(table(unlist(tmp)))
  names(freq_table) <- c("word", "freq")
  freq_table$freq <- as.numeric(freq_table$freq)
  freq_table$word <- as.character(freq_table$word)
  freq_table <- subset(freq_table, nchar(word) > 2)
  freq_table$word <- as.factor(as.character(freq_table$word))
  rownames(freq_table) <- freq_table$word 
  rm(POStagged, POStags, prp1, prp2, prp3, s, word_token_annotator)
  return(freq_table)
}

# path 
path_local <- "C:/Users/user/Documents/ds/2econsulting/newsletter/"
path_git <- "C:/Users/user/Documents/2econsulting.github.io/data/newsletter/"

# load data
filename <- paste0(path_git,"input/total_",gsub("-", "", Sys.Date()),".csv")
total <- read.csv(filename)

# load dictionary
filename <- paste0(path_git,"input/dictionary.csv")
dictionary <- read.csv(filename)

# data
tmp_text <- total$text
freq_table <- KeywordExtract(tmp_text)

# filtering
freq_table <- as.data.table(freq_table)
freq_table <- freq_table[!(freq_table$word %in% dictionary$rm_word), ]

# img save
fileName <- paste0(path_git,"input/png/wordcloud.png")
png(fileName)
wordcloud(freq_table$word, freq_table$freq, min.freq = 5, max.words = 200, rot.per = 0.35, random.order = FALSE, colors = brewer.pal(8, "Dark2"), scale = c(4.5, 0.25))
dev.off()
