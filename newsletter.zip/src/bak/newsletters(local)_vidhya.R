library(rvest)
library(dplyr)
library(stringr)
library(data.table)
library(R2HTML)
library(NLP)
library(openNLP)
options(timeout= 4000000)


###### Local ############################################################
path <- "C:/Users/user/Documents/DS_lab/2econsulting.github.io/data/newsletter/"

from <- substr(as.character(format(Sys.time()-(14*24*60*60), "%Y-%m-%d %H:%M:%00")),1, 10)
to   <- substr(as.character(format(Sys.time(), "%Y-%m-%d %H:%M:%00")), 1, 10)

# analyticsvidhya ----
# Get the url 
for (j in 1:3) {
  i <- "https://www.analyticsvidhya.com/blog-archive/"
  tmp_base <- read_html(i)
  print("Done")
}
Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.entry-date')
tmp_time <- html_text(tmp_time)

tmp_time <- gsub("\n","",tmp_time)
tmp_time <- gsub("\n ","",tmp_time)
tmp_time <- gsub(paste0(substr(from, 1, 4), " "),"2018",tmp_time)
tmp_time <- gsub(paste0(substr(to, 1, 4), " "),"2018",tmp_time)
tmp_time <- gsub(",","",tmp_time)
tmp_time <- gsub(" J","J",tmp_time)

# 일자 변수 변환: format에서 %B가 안되기 때문에 숫자로 변환 후 %m 이용 
tmp_time <- gsub("January", 1, tmp_time)
tmp_time <- gsub("February", 2, tmp_time)
tmp_time <- gsub("March", 3, tmp_time)
tmp_time <- gsub("April", 4, tmp_time)
tmp_time <- gsub("May", 5, tmp_time)
tmp_time <- gsub("June", 6, tmp_time)
tmp_time <- gsub("July", 7, tmp_time)
tmp_time <- gsub("August", 8, tmp_time)
tmp_time <- gsub("September", 9, tmp_time)
tmp_time <- gsub("October", 10, tmp_time)
tmp_time <- gsub("November", 11, tmp_time)
tmp_time <- gsub("December", 12, tmp_time)
tmp_time <- as.Date(tmp_time, format = '%m %d %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, '.entry-title')
tmp_head <- html_text(tmp_head)

tmp_head <- tmp_head[!(tmp_head %in% tmp_head[[1]])]
tmp_head <- gsub("\n\n","",tmp_head)
tmp_head <- gsub(" \n","",tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, '.entry-title a')
tmp_url <- html_attr(tmp_url, 'href')

# make data frame
vidhya <- data.frame(site = "vidhya", date = tmp_time, headline = tmp_head, url_address = tmp_url)
vidhya <- as.data.table(unique(vidhya))

# Get the valid information 
vidhya <- vidhya[from < vidhya$date & to >= vidhya$date, ]

# Collect the data from valid url
tmp_text <- c()
for (i in vidhya[["url_address"]]){
  for (j in 1:5) {
    tmp <- read_html(i)
    print("Done")
  }
  Sys.sleep(3)
  tmp <- html_nodes(tmp, 'p')
  tmp <- html_text(tmp) 
  Sys.sleep(3)
  tmp <- tmp[1:(length(tmp)-11)] # remove advertisement
  tmp <- tmp[str_length(tmp)>1] # remove empty line
  tmp <- paste(unlist(tmp), collapse =" ")
  tmp_text <- c(tmp_text, tmp)
  Sys.sleep(2)
}
vidhya$text <- tmp_text
filename <- paste0(path,"input/vidhya_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
write.csv(vidhya, filename, row.names = FALSE)

html <- paste0('<ul><li><a href="',vidhya$url_address,'">',vidhya$headline,'</a></li></ul>')
write.table(html, paste0(path,"input/html/vidhya_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, filename, html)


rm(list = ls())