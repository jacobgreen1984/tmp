library(rvest)
library(dplyr)
library(stringr)
library(data.table)
library(R2HTML)
library(NLP)
library(openNLP)
options(timeout= 4000000)


###### Local ############################################################
path <- "C:/Users/user/Documents/DS_lab/2econsulting.github.io/data/newsletter/"

from <- substr(as.character(format(Sys.time()-(14*24*60*60), "%Y-%m-%d %H:%M:%00")),1, 10)
to   <- substr(as.character(format(Sys.time(), "%Y-%m-%d %H:%M:%00")), 1, 10)

# analyticsvidhya ----
# Get the url 
for (j in 1:5) {
  i <- "https://www.datacamp.com/community/blog"
  tmp_base <- read_html(i)
  print("Done")
}

Sys.sleep(3)
tmp_time <- html_nodes(tmp_base, '.jsx-566588255 a .date')
tmp_time <- html_text(tmp_time)

# 일자 변수 변환: format에서 %B가 안되기 때문에 숫자로 변환 후 %m 이용 
tmp_time <- gsub("st","",tmp_time)
tmp_time <- gsub("nd","",tmp_time)
tmp_time <- gsub("rd","",tmp_time)
tmp_time <- gsub("th","",tmp_time)

tmp_time <- gsub("January", 1, tmp_time)
tmp_time <- gsub("February", 2, tmp_time)
tmp_time <- gsub("March", 3, tmp_time)
tmp_time <- gsub("April", 4, tmp_time)
tmp_time <- gsub("May", 5, tmp_time)
tmp_time <- gsub("June", 6, tmp_time)
tmp_time <- gsub("July", 7, tmp_time)
tmp_time <- gsub("August", 8, tmp_time)
tmp_time <- gsub("September", 9, tmp_time)
tmp_time <- gsub("October", 10, tmp_time)
tmp_time <- gsub("November", 11, tmp_time)
tmp_time <- gsub("December", 12, tmp_time)
tmp_time <- as.Date(tmp_time, format = '%m %d, %Y')

# Get the title
tmp_head <- html_nodes(tmp_base, 'h2')
tmp_head <- html_text(tmp_head)

# Get the url
tmp_url <- html_nodes(tmp_base, 'h2 a')
tmp_url <- html_attr(tmp_url, 'href')
url_list <- c()
for (i in tmp_url){
  tmp <- paste0("https://www.datacamp.com",i)
  url_list <- c(url_list, tmp)
}

# make data frame
datacamp <- data.frame(site = "datacamp", date = as.Date(tmp_time), headline = as.character(tmp_head), url_address = as.character(url_list))
datacamp <- as.data.table(unique(datacamp))

# Get the valid information 
datacamp <- datacamp[from < datacamp$date & to >= datacamp$date, ]

# Collect the data from valid url
tmp_text <- c()
for (i in datacamp[["url_address"]]){
  tmp <- read_html(i)
  for (j in 1:5) {
    tmp <- read_html(i)
    print("Done")
  }
  Sys.sleep(3)
  tmp <- html_nodes(tmp, 'p') 
  tmp <- html_text(tmp) 
  Sys.sleep(3)
  tmp <- tmp[str_length(tmp)>1] # remove empty line
  tmp <- tmp[2:(length(tmp))] # remove advertisement
  tmp <- paste(unlist(tmp), collapse =" ")
  tmp_text <- c(tmp_text, tmp)
  Sys.sleep(3)
}
datacamp$text <- tmp_text
filename <- paste0(path,"input/datacamp_",gsub("-", "", substr(Sys.time(), 1, 10)),".csv")
write.csv(datacamp, filename, row.names = FALSE)

html <- paste0('<ul><li><a href="',datacamp$url_address,'">',datacamp$headline,'</a></li></ul>')
write.table(html, paste0(path,"input/html/datacamp_out.html"), row.names = FALSE, col.names = FALSE, quote = FALSE)
rm(tmp_base, tmp_time, tmp_head, tmp_url, tmp_text, tmp, i, filename, html, url_list)


rm(list = ls())