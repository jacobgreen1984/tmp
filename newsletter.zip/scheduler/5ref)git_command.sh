cd /c/Users/user/Documents/2econsulting.github.io
git pull
git add .
git commit -m "Hyunseo"
git push -u origin master
