cd /c/Users/user/Documents/DS_lab/2econsulting.github.io
git pull