# title : sample
# author : hjy

# library 
library(data.table)
library(rJava)
library(memoise)
library(KoNLP)

# set path 
PATH_INPUT = "c:/Users/11900053/신시장보험파트/test"

# convert hwp to txt 
A = file.path(PATH_INPUT,list.files(PATH_INPUT))
B = gsub(".hwp",".txt",A)
cmd = paste("hwp5txt",A,">",B)
system(iconv(cmd, "UTF-8","CP949"),intern = T)

# read data
data = readLines("../신시장보험파트/test/샘플.txt",encoding="UTF-8")
head(data)







