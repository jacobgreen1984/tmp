# title : 200_MITM100(barchart)
# author : hjy

# ----
# bar chart
# ----

tmp = data.table(table(data))
tmp = tmp[order(N,decreasing = T),]
plotly::plot_ly(data=head(tmp,topN),x=~data,y=~N,type="bar")

