# title : 101_MITM100(��ó��)
# author : hjy

# clean text
tmp = data
tmp = tmp[tmp!=""]
tmp = gsub("<code>.*?</code>","",tmp)
tmp = gsub("href\\S+", "", tmp)
tmp = gsub("http\\S+", "", tmp)
tmp = gsub("([<>-])|[[:punct:]]", "\\1", tmp) # remove punctuation except "-/</>" 
tmp = gsub("<.*?>", "", tmp)
tmp = gsub("\n", " ", tmp)  # replace newline with a space
tmp = gsub("(\\S+\\d+|\\d+)\\S+", "", tmp) # remove words having any digits
tmp = gsub("<a", "", tmp)
tmp = gsub("\\s+", " ", tmp)
tmp = gsub("[�ۡ�-��-]", " ", tmp)
tmp = gsub("��", "", tmp)
tmp = gsub("\\s+", " ", tmp)
tmp = stringr::str_trim(tmp)
tmp = tmp[tmp!=""]
data = tmp

# search 
cleantext = data 
cleantext = cleantext[nchar(cleantext)>=10]
#earch_words = c("������","Ȱ��")
#for(i in search_words){
#  cleantext = grep(i,cleantext,value=T)
#}

# save memory 
rm(tmp)
gc(reset=T)

# extractNoun
data = extractNoun(data)
data = unlist(data)
head(data)

# remove words 
remove_dic = fread(file.path(PATH_INPUT,"remove_dic.csv"))$words
for(i in 1:length(remove_dic)){
  cat(">> remove word(s):",remove_dic[i],"\n")
  data = stringr::str_replace_all(data, remove_dic[i],'')
}

# filtering based on nchar
data = data[nchar(data)>=2]
head(data)





