# title : 201_MITM100(wordcloud)
# author : hjy

# ----
# wordcloud
# ----

tmp = table(data)
tmp = tmp[tmp>=5]
wordcloud2(tmp)

#tmp = table(data)
#tmp = tmp[tmp>=5]
#tmp = data.table(tmp)
#pal = brewer.pal(5,"Dark2")
#wordcloud(tmp$data,tmp$N,c(8,.3),2,,F,,.15,pal)
