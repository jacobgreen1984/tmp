

# convert hwp to txt 
A = file.path(PATH_INPUT,list.files(PATH_INPUT))
B = gsub(".hwp",".txt",A)
cmd = paste("hwp5txt",A,">",B)
system(iconv(cmd, "UTF-8","CP949"),intern = T)