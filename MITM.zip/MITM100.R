# title : MITM100
# author : hjy

# library 
library(data.table)
library(rJava)
library(memoise)
library(KoNLP)
library(wordcloud2)
library(tidyverse)
library(tidytext)

# set path 
PATH_PRJT = "c:/Users/11900053/MITM"
PATH_INPUT = "c:/Users/11900053/MITM/input"
PATH_CODE = "c:/Users/11900053/MITM/code"

# read data
data = readLines(file.path(PATH_INPUT,"sample.txt"),encoding="UTF-8")
head(data)

# sampling
#data = head(data,100)

# preprocess
source(file.path(PATH_CODE,"101_MITM100(preprocess).R"))

# keyword
topN = 50
source(file.path(PATH_CODE,"200_MITM100(barchart).R"))
source(file.path(PATH_CODE,"201_MITM100(wordcloud).R"))

































